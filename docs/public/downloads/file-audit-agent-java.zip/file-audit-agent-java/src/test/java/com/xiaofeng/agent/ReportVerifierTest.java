package com.xiaofeng.agent;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

final class ReportVerifierTest {
    @TempDir
    Path root;

    private WorkspaceTools tools;
    private Settings settings;

    @BeforeEach
    void setUp() throws Exception {
        Files.writeString(root.resolve("a.md"), "TODO\n", StandardCharsets.UTF_8);
        settings = new Settings(root);
        tools = new WorkspaceTools(settings);
    }

    @Test
    void acceptsEvidenceBackedReport() throws Exception {
        String report = """
                # 资料盘点报告

                文件总数：1

                ## 文件概况

                - `a.md` 是文本资料。

                ## 需要关注

                - `a.md` 中还有待办。

                ## 建议下一步

                - 人工确认待办是否仍有效。
                """;
        tools.saveReportDraft(report);

        VerificationResult result = ReportVerifier.verify(tools, settings.draftPath());
        assertTrue(result.passed(), result.issues().toString());
    }

    @Test
    void rejectsWrongCountAndFakePath() throws Exception {
        String report = """
                # 资料盘点报告

                文件总数：9

                ## 文件概况

                - `missing.md`

                ## 需要关注

                - 无。

                ## 建议下一步

                - 检查。
                """;
        tools.saveReportDraft(report);

        VerificationResult result = ReportVerifier.verify(tools, settings.draftPath());
        assertFalse(result.passed());
        assertTrue(result.issues().stream().anyMatch(issue -> issue.contains("总数")));
        assertTrue(result.issues().stream().anyMatch(issue -> issue.contains("不存在")));
    }
}
