package com.xiaofeng.agent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.openai.models.responses.FunctionTool;
import com.openai.models.responses.ResponseInputItem;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

final class FileAuditAgentTest {
    @TempDir
    Path root;

    @BeforeEach
    void setUp() throws Exception {
        Files.writeString(root.resolve("a.md"), "TODO: check\n", StandardCharsets.UTF_8);
    }

    @Test
    void completesOnlyAfterReportPassesVerification() {
        String report = """
                # 资料盘点报告

                文件总数：1

                ## 文件概况

                - `a.md` 是文本资料。

                ## 需要关注

                - `a.md` 有一条待办。

                ## 建议下一步

                - 人工核对待办。
                """;
        ScriptedModel model = new ScriptedModel(List.of(
                toolTurn("call-1", "list_files", "{\"relative_dir\":\".\"}"),
                toolTurn("call-2", "search_text", "{\"query\":\"TODO\",\"relative_dir\":\".\"}"),
                toolTurn("call-3", "save_report_draft", jsonContent(report)),
                new ModelTurn(List.of(), List.of(), "草稿已生成，等待人工确认。")));
        Settings settings = new Settings(root, "test-model", 6, 6_000, 200, 3);
        WorkspaceTools tools = new WorkspaceTools(settings);

        AgentRunResult result = new FileAuditAgent(settings, model, tools).run("盘点目录");

        assertTrue(result.verification().passed());
        assertEquals("ready_for_approval", result.state().status);
        assertEquals(3, result.state().toolEvents.size());
        RunState loaded = new CheckpointStore(settings.agentDir()).load(result.state().runId);
        assertEquals("ready_for_approval", loaded.status);
        assertEquals(result.state().inputItems.size(), loaded.inputItems.size());
    }

    @Test
    void stopsRepeatedToolLoop() {
        List<ModelTurn> turns = new ArrayList<>();
        for (int index = 0; index < 3; index++) {
            turns.add(toolTurn(
                    "call-" + index,
                    "list_files",
                    "{\"relative_dir\":\".\"}"));
        }
        Settings settings = new Settings(root, "test-model", 5, 6_000, 200, 3);
        WorkspaceTools tools = new WorkspaceTools(settings);
        FileAuditAgent agent = new FileAuditAgent(settings, new ScriptedModel(turns), tools);

        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> agent.run("盘点目录"));
        assertTrue(exception.getMessage().contains("无效循环"));
    }

    private static ModelTurn toolTurn(String callId, String name, String arguments) {
        return new ModelTurn(
                List.of(),
                List.of(new ToolCall(callId, name, arguments)),
                "");
    }

    private static String jsonContent(String report) {
        try {
            return new com.fasterxml.jackson.databind.ObjectMapper()
                    .writeValueAsString(java.util.Map.of("content", report));
        } catch (com.fasterxml.jackson.core.JsonProcessingException exception) {
            throw new IllegalStateException(exception);
        }
    }

    private static final class ScriptedModel implements AgentModel {
        private final Deque<ModelTurn> turns;

        private ScriptedModel(List<ModelTurn> turns) {
            this.turns = new ArrayDeque<>(turns);
        }

        @Override
        public ModelTurn complete(
                String instructions,
                List<FunctionTool> tools,
                List<ResponseInputItem> inputItems) {
            return turns.removeFirst();
        }
    }
}
