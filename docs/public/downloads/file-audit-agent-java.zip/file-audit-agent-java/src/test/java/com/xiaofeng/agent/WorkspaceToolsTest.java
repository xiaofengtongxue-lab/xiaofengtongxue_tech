package com.xiaofeng.agent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

final class WorkspaceToolsTest {
    @TempDir
    Path root;

    @Test
    void listsAndSearchesRealFiles() throws Exception {
        Files.createDirectories(root.resolve("notes"));
        Files.writeString(root.resolve("notes/todo.md"), "TODO: verify links\n", StandardCharsets.UTF_8);
        WorkspaceTools tools = new WorkspaceTools(new Settings(root));

        Map<String, Object> listed = tools.listFiles(".");
        assertEquals(1, listed.get("returned"));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> files = (List<Map<String, Object>>) listed.get("files");
        assertEquals("notes/todo.md", files.getFirst().get("path"));

        Map<String, Object> searched = tools.searchText("todo", ".");
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> matches = (List<Map<String, Object>>) searched.get("matches");
        assertEquals(1, matches.getFirst().get("line"));
    }

    @Test
    void rejectsPathTraversal() throws Exception {
        WorkspaceTools tools = new WorkspaceTools(new Settings(root));
        Map<String, Object> result = tools.dispatch(
                "read_text_file", "{\"path\":\"../secret.txt\"}");

        assertFalse((Boolean) result.get("ok"));
        assertEquals("invalid_tool_call", result.get("error_code"));
    }

    @Test
    void draftIsNotVisibleSourceMaterial() throws Exception {
        Files.createDirectories(root.resolve("notes"));
        Files.writeString(root.resolve("notes/todo.md"), "TODO\n", StandardCharsets.UTF_8);
        WorkspaceTools tools = new WorkspaceTools(new Settings(root));
        tools.saveReportDraft("# Draft");

        assertEquals(1, tools.listFiles(".").get("returned"));
    }
}
