package com.xiaofeng.agent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

final class ApprovalServiceTest {
    @TempDir
    Path root;

    @Test
    void requiresMatchingConfirmationAndUnchangedDraft() throws Exception {
        Path draft = root.resolve("draft.md");
        Path target = root.resolve("reports/inventory.md");
        Files.writeString(draft, "# Draft\n", StandardCharsets.UTF_8);
        ApprovalRequest request = ApprovalService.makeRequest(draft, "abc123");

        assertThrows(
                SecurityException.class,
                () -> ApprovalService.publish(draft, target, request, "yes"));
        assertFalse(Files.exists(target));

        Path published = ApprovalService.publish(
                draft, target, request, "APPROVE abc123");
        assertEquals("# Draft\n", Files.readString(published, StandardCharsets.UTF_8));
    }
}
