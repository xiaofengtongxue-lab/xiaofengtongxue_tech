package com.xiaofeng.agent;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ReportVerifier {
    private static final List<String> REQUIRED_SECTIONS = List.of(
            "## 文件概况", "## 需要关注", "## 建议下一步");
    private static final Pattern H1 = Pattern.compile("^# [^#].+$", Pattern.MULTILINE);
    private static final Pattern FILE_COUNT = Pattern.compile("文件总数[：:]\\s*(\\d+)");
    private static final Pattern EVIDENCE = Pattern.compile("`([^`\\n]+)`");

    private ReportVerifier() {}

    public static VerificationResult verify(WorkspaceTools tools, Path draftPath) {
        List<String> issues = new ArrayList<>();
        List<Path> files = tools.visibleFiles();

        if (!Files.isRegularFile(draftPath)) {
            return new VerificationResult(false, List.of("报告草稿不存在"), files.size());
        }

        String content;
        try {
            content = Files.readString(draftPath, StandardCharsets.UTF_8);
        } catch (IOException exception) {
            return new VerificationResult(false, List.of("读取报告草稿失败"), files.size());
        }

        long h1Count = H1.matcher(content).results().count();
        if (h1Count != 1) {
            issues.add("报告应有且仅有一个 H1，当前为 " + h1Count + " 个");
        }

        for (String section : REQUIRED_SECTIONS) {
            if (!content.contains(section)) {
                issues.add("缺少章节：" + section);
            }
        }

        Matcher countMatcher = FILE_COUNT.matcher(content);
        if (!countMatcher.find()) {
            issues.add("没有写出“文件总数：N”");
        } else if (Integer.parseInt(countMatcher.group(1)) != files.size()) {
            issues.add("文件总数与真实目录不一致：报告写 "
                    + countMatcher.group(1)
                    + "，实际为 "
                    + files.size());
        }

        Set<String> evidencePaths = new LinkedHashSet<>();
        EVIDENCE.matcher(content).results().forEach(match -> evidencePaths.add(match.group(1)));
        int validEvidence = 0;
        for (String value : evidencePaths) {
            if (value.startsWith("TODO")
                    || value.startsWith("FIXME")
                    || (value.contains(" ") && !value.contains("/"))) {
                continue;
            }

            try {
                Path candidate = Path.of(value);
                if (candidate.isAbsolute() || containsParentTraversal(candidate)) {
                    issues.add("证据路径不安全：" + value);
                    continue;
                }
                Path resolved = tools.root().resolve(candidate).normalize().toAbsolutePath();
                if (resolved.startsWith(tools.root()) && Files.isRegularFile(resolved)) {
                    validEvidence++;
                } else if (hasSuffix(candidate)) {
                    issues.add("报告引用了不存在的文件：" + value);
                }
            } catch (InvalidPathException exception) {
                issues.add("报告引用了无效路径：" + value);
            }
        }

        if (!files.isEmpty() && validEvidence == 0) {
            issues.add("报告没有引用任何真实文件路径作为证据");
        }

        return new VerificationResult(issues.isEmpty(), List.copyOf(issues), files.size());
    }

    private static boolean containsParentTraversal(Path path) {
        for (Path part : path) {
            if (part.toString().equals("..")) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasSuffix(Path path) {
        String name = path.getFileName().toString();
        return name.lastIndexOf('.') > 0;
    }
}
