package com.xiaofeng.agent;

import com.openai.models.responses.ResponseInputItem;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class RunState {
    public String goal;
    public String runId;
    public String status;
    public int nextStep;
    public List<ResponseInputItem> inputItems;
    public List<ToolEvent> toolEvents;
    public String updatedAt;

    public RunState() {
        inputItems = new ArrayList<>();
        toolEvents = new ArrayList<>();
    }

    public RunState(String goal, List<ResponseInputItem> inputItems) {
        this.goal = goal;
        this.runId = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        this.status = "running";
        this.nextStep = 0;
        this.inputItems = new ArrayList<>(inputItems);
        this.toolEvents = new ArrayList<>();
        this.updatedAt = Instant.now().toString();
    }
}
