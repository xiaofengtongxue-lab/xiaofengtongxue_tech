package com.xiaofeng.agent;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;

public final class CheckpointStore {
    private final Path directory;
    private final ObjectMapper mapper;

    public CheckpointStore(Path agentDir) {
        directory = agentDir.resolve("checkpoints");
        mapper = new ObjectMapper().findAndRegisterModules();
    }

    public Path save(RunState state) {
        try {
            Files.createDirectories(directory);
            state.updatedAt = Instant.now().toString();
            Path target = directory.resolve(state.runId + ".json");
            Path temporary = directory.resolve(state.runId + ".tmp");
            mapper.writerWithDefaultPrettyPrinter().writeValue(temporary.toFile(), state);
            FileSupport.replace(temporary, target);
            return target;
        } catch (IOException exception) {
            throw new IllegalStateException("保存检查点失败", exception);
        }
    }

    public RunState load(String runId) {
        try {
            Path target = directory.resolve(runId + ".json");
            RunState state = mapper.readValue(target.toFile(), RunState.class);
            if (state.inputItems == null) {
                state.inputItems = new ArrayList<>();
            }
            if (state.toolEvents == null) {
                state.toolEvents = new ArrayList<>();
            }
            return state;
        } catch (IOException exception) {
            throw new IllegalStateException("读取检查点失败：" + runId, exception);
        }
    }
}
