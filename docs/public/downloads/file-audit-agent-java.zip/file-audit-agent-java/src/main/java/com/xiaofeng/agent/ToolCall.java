package com.xiaofeng.agent;

public record ToolCall(String callId, String name, String arguments) {}
