package com.xiaofeng.agent;

import com.openai.models.responses.ResponseInputItem;
import java.util.List;

public record ModelTurn(
        List<ResponseInputItem> items,
        List<ToolCall> toolCalls,
        String outputText) {}
