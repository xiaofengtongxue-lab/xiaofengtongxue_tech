package com.xiaofeng.agent;

import java.nio.file.Path;

public record Settings(
        Path root,
        String model,
        int maxSteps,
        int maxReadChars,
        int maxFiles,
        int maxToolRepeats) {

    public Settings {
        root = root.toAbsolutePath().normalize();
    }

    public Settings(Path root) {
        this(root, "deepseek-v4-pro", 10, 6_000, 200, 3);
    }

    public Path agentDir() {
        return root.resolve(".agent");
    }

    public Path draftPath() {
        return agentDir().resolve("drafts/inventory.md");
    }

    public Path reportPath() {
        return root.resolve("reports/inventory.md");
    }
}
