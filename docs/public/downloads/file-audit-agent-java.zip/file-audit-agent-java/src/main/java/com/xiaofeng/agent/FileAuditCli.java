package com.xiaofeng.agent;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

public final class FileAuditCli {
    private static final String DEFAULT_GOAL =
            "盘点这个工作目录：统计文件，找出包含 TODO 或 FIXME 的文本，生成一份带真实路径证据的资料清单。不要修改原文件。";

    private FileAuditCli() {}

    public static void main(String[] args) {
        int exitCode = run(args);
        if (exitCode != 0) {
            System.exit(exitCode);
        }
    }

    static int run(String[] args) {
        Arguments parsed;
        try {
            parsed = Arguments.parse(args);
        } catch (IllegalArgumentException exception) {
            System.err.println(exception.getMessage());
            printUsage();
            return 2;
        }

        if (parsed.help) {
            printUsage();
            return 0;
        }
        if (System.getenv("OPENAI_API_KEY") == null || System.getenv("OPENAI_API_KEY").isBlank()) {
            System.err.println("缺少 OPENAI_API_KEY。请只在自己的终端设置，不要写进项目文件。");
            return 2;
        }

        Settings defaults = new Settings(parsed.root);
        Settings settings = new Settings(
                parsed.root,
                parsed.model,
                parsed.maxSteps,
                defaults.maxReadChars(),
                defaults.maxFiles(),
                defaults.maxToolRepeats());

        try {
            WorkspaceTools tools = new WorkspaceTools(settings);
            FileAuditAgent agent = new FileAuditAgent(
                    settings,
                    new OpenAIResponsesModel(settings.model()),
                    tools);
            AgentRunResult result = agent.run(parsed.goal, parsed.resumeRunId);

            System.out.println("\n草稿已通过验收：" + result.draftPath());
            System.out.println("真实文件数：" + result.verification().actualFileCount());
            System.out.println("运行编号：" + result.state().runId);
            if (!result.finalText().isBlank()) {
                System.out.println("模型说明：" + result.finalText().strip());
            }

            if (parsed.draftOnly) {
                System.out.println("已按 --draft-only 停在草稿阶段。");
                return 0;
            }

            String token = "%06x".formatted(new SecureRandom().nextInt(0x1000000));
            ApprovalRequest request = ApprovalService.makeRequest(result.draftPath(), token);
            System.out.println("\n请先打开草稿检查。确认发布时输入下面这行原文：");
            System.out.println(request.confirmationText());
            System.out.print("> ");
            String confirmation = new BufferedReader(new InputStreamReader(System.in)).readLine();
            Path reportPath = ApprovalService.publish(
                    result.draftPath(),
                    settings.reportPath(),
                    request,
                    confirmation == null ? "" : confirmation);
            System.out.println("报告已发布：" + reportPath);
            return 0;
        } catch (SecurityException exception) {
            System.err.println(exception.getMessage());
            return 3;
        } catch (IOException exception) {
            System.err.println("读取确认输入失败：" + exception.getMessage());
            return 4;
        } catch (RuntimeException exception) {
            System.err.println(exception.getMessage());
            return 1;
        }
    }

    private static void printUsage() {
        System.out.println("""
                用法：
                  java -jar target/file-audit-agent.jar --root DIRECTORY [选项]

                选项：
                  --goal TEXT       本次盘点目标
                  --model MODEL     当前 API 项目可用的模型 ID
                  --max-steps N     最大 Agent 循环轮数，默认 10
                  --resume RUN_ID   从 .agent/checkpoints 恢复
                  --draft-only      验收后停在草稿阶段
                  --help            显示帮助
                """);
    }

    private static final class Arguments {
        private Path root;
        private String goal = DEFAULT_GOAL;
        private String model = environmentModel();
        private int maxSteps = 10;
        private String resumeRunId;
        private boolean draftOnly;
        private boolean help;

        private static Arguments parse(String[] args) {
            Arguments result = new Arguments();
            Map<String, String> values = new HashMap<>();
            for (int index = 0; index < args.length; index++) {
                String argument = args[index];
                if (argument.equals("--draft-only")) {
                    result.draftOnly = true;
                } else if (argument.equals("--help") || argument.equals("-h")) {
                    result.help = true;
                } else if (argument.startsWith("--")) {
                    if (index + 1 >= args.length) {
                        throw new IllegalArgumentException("缺少参数值：" + argument);
                    }
                    values.put(argument, args[++index]);
                } else {
                    throw new IllegalArgumentException("未知参数：" + argument);
                }
            }

            SetValidator.rejectUnknown(values);
            if (values.containsKey("--root")) {
                result.root = Path.of(values.get("--root"));
            }
            if (values.containsKey("--goal")) {
                result.goal = values.get("--goal");
            }
            if (values.containsKey("--model")) {
                result.model = values.get("--model");
            }
            if (values.containsKey("--max-steps")) {
                result.maxSteps = Integer.parseInt(values.get("--max-steps"));
            }
            result.resumeRunId = values.get("--resume");

            if (!result.help && result.root == null) {
                throw new IllegalArgumentException("缺少必填参数：--root");
            }
            if (result.maxSteps < 1) {
                throw new IllegalArgumentException("--max-steps 必须大于 0");
            }
            return result;
        }

        private static String environmentModel() {
            String value = System.getenv("OPENAI_MODEL");
            return value == null || value.isBlank() ? "deepseek-v4-pro" : value;
        }
    }

    private static final class SetValidator {
        private static final java.util.Set<String> ALLOWED = java.util.Set.of(
                "--root", "--goal", "--model", "--max-steps", "--resume");

        private static void rejectUnknown(Map<String, String> values) {
            for (String key : values.keySet()) {
                if (!ALLOWED.contains(key)) {
                    throw new IllegalArgumentException("未知参数：" + key);
                }
            }
        }
    }
}
