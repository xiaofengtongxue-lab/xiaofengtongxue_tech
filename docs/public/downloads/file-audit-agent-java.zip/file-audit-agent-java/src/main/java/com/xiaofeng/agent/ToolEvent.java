package com.xiaofeng.agent;

import java.util.Map;

public record ToolEvent(
        int step,
        String name,
        Map<String, Object> argumentsSummary,
        boolean ok,
        String errorCode) {}
