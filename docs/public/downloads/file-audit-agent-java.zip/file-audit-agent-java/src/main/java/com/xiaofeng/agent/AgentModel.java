package com.xiaofeng.agent;

import com.openai.models.responses.FunctionTool;
import com.openai.models.responses.ResponseInputItem;
import java.util.List;

@FunctionalInterface
public interface AgentModel {
    ModelTurn complete(
            String instructions,
            List<FunctionTool> tools,
            List<ResponseInputItem> inputItems);
}
