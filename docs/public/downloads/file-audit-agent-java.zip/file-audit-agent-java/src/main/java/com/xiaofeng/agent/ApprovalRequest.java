package com.xiaofeng.agent;

public record ApprovalRequest(
        String token,
        String draftSha256,
        String confirmationText) {}
