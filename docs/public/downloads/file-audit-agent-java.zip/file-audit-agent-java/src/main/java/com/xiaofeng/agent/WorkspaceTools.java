package com.xiaofeng.agent;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.openai.core.JsonValue;
import com.openai.models.responses.FunctionTool;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

public final class WorkspaceTools {
    private static final Set<String> TEXT_SUFFIXES = Set.of(
            ".csv", ".java", ".json", ".md", ".py", ".txt", ".yaml", ".yml");

    private final Settings settings;
    private final Path root;
    private final ObjectMapper mapper = new ObjectMapper();
    private final List<FunctionTool> schemas;

    public WorkspaceTools(Settings settings) {
        this.settings = settings;
        root = settings.root();
        if (!Files.isDirectory(root)) {
            throw new ToolException("工作目录不存在：" + root);
        }
        schemas = List.of(
                listFilesSchema(),
                readTextSchema(),
                searchTextSchema(),
                saveDraftSchema());
    }

    public Path root() {
        return root;
    }

    public List<FunctionTool> schemas() {
        return schemas;
    }

    public Map<String, Object> dispatch(String name, String argumentsJson) {
        if (!Set.of("list_files", "read_text_file", "search_text", "save_report_draft").contains(name)) {
            return error("unknown_tool", "未知工具：" + name, false);
        }

        try {
            JsonNode node = mapper.readTree(argumentsJson);
            if (node == null || !node.isObject()) {
                throw new ToolException("工具参数必须是 JSON 对象");
            }
            Map<String, Object> arguments = mapper.convertValue(
                    node, new TypeReference<LinkedHashMap<String, Object>>() {});
            Map<String, Object> data = switch (name) {
                case "list_files" -> {
                    requireOnly(arguments, Set.of("relative_dir"));
                    yield listFiles(requiredString(arguments, "relative_dir"));
                }
                case "read_text_file" -> {
                    requireOnly(arguments, Set.of("path"));
                    yield readTextFile(requiredString(arguments, "path"));
                }
                case "search_text" -> {
                    requireOnly(arguments, Set.of("query", "relative_dir"));
                    yield searchText(
                            requiredString(arguments, "query"),
                            requiredString(arguments, "relative_dir"));
                }
                case "save_report_draft" -> {
                    requireOnly(arguments, Set.of("content"));
                    yield saveReportDraft(requiredString(arguments, "content"));
                }
                default -> throw new IllegalStateException("未处理的工具：" + name);
            };
            Map<String, Object> response = new LinkedHashMap<>();
            response.put("ok", true);
            response.put("data", data);
            return response;
        } catch (JsonProcessingException | ToolException | InvalidPathException | ClassCastException exception) {
            return error("invalid_tool_call", exception.getMessage(), false);
        } catch (IOException exception) {
            return error("io_error", "文件操作失败：" + exception.getClass().getSimpleName(), true);
        }
    }

    public Map<String, Object> listFiles(String relativeDir) throws IOException {
        Path directory = resolve(relativeDir);
        if (!Files.isDirectory(directory)) {
            throw new ToolException("不是目录：" + relativeDir);
        }

        List<Map<String, Object>> files = new ArrayList<>();
        try (Stream<Path> paths = Files.walk(directory)) {
            for (Path path : paths.sorted().toList()) {
                if (!Files.isRegularFile(path) || Files.isSymbolicLink(path) || isInternal(path)) {
                    continue;
                }
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("path", displayPath(path));
                item.put("bytes", Files.size(path));
                String suffix = suffix(path);
                item.put("type", suffix.isEmpty() ? "(no suffix)" : suffix);
                files.add(item);
                if (files.size() >= settings.maxFiles()) {
                    break;
                }
            }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("directory", displayPath(directory));
        result.put("files", files);
        result.put("returned", files.size());
        result.put("limit", settings.maxFiles());
        return result;
    }

    public Map<String, Object> readTextFile(String relativePath) throws IOException {
        Path target = resolve(relativePath);
        if (!Files.isRegularFile(target)) {
            throw new ToolException("文件不存在：" + relativePath);
        }
        if (!TEXT_SUFFIXES.contains(suffix(target))) {
            throw new ToolException("本教程只允许读取文本文件：" + TEXT_SUFFIXES.stream().sorted().toList());
        }

        String content = Files.readString(target, StandardCharsets.UTF_8);
        boolean truncated = content.length() > settings.maxReadChars();
        if (truncated) {
            content = content.substring(0, settings.maxReadChars());
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("path", displayPath(target));
        result.put("content", content);
        result.put("truncated", truncated);
        result.put("max_chars", settings.maxReadChars());
        return result;
    }

    public Map<String, Object> searchText(String query, String relativeDir) throws IOException {
        if (query.isBlank()) {
            throw new ToolException("搜索词不能为空");
        }
        Path directory = resolve(relativeDir);
        if (!Files.isDirectory(directory)) {
            throw new ToolException("不是目录：" + relativeDir);
        }

        String needle = query.toLowerCase(Locale.ROOT);
        List<Map<String, Object>> matches = new ArrayList<>();
        try (Stream<Path> paths = Files.walk(directory)) {
            List<Path> sortedPaths = paths.sorted(Comparator.naturalOrder()).toList();
            for (Path path : sortedPaths) {
                if (!Files.isRegularFile(path)
                        || Files.isSymbolicLink(path)
                        || isInternal(path)
                        || !TEXT_SUFFIXES.contains(suffix(path))) {
                    continue;
                }

                List<String> lines;
                try {
                    lines = Files.readAllLines(path, StandardCharsets.UTF_8);
                } catch (java.nio.charset.MalformedInputException ignored) {
                    continue;
                }
                for (int index = 0; index < lines.size(); index++) {
                    String line = lines.get(index);
                    if (!line.toLowerCase(Locale.ROOT).contains(needle)) {
                        continue;
                    }
                    Map<String, Object> match = new LinkedHashMap<>();
                    match.put("path", displayPath(path));
                    match.put("line", index + 1);
                    match.put("text", line.substring(0, Math.min(240, line.length())));
                    matches.add(match);
                    if (matches.size() >= 30) {
                        return searchResult(query, matches, true);
                    }
                }
            }
        }
        return searchResult(query, matches, false);
    }

    public Map<String, Object> saveReportDraft(String content) throws IOException {
        if (content.isBlank()) {
            throw new ToolException("报告内容不能为空");
        }
        if (content.length() > 50_000) {
            throw new ToolException("报告草稿不能超过 50000 个字符");
        }

        Path target = settings.draftPath();
        Files.createDirectories(target.getParent());
        Path temporary = target.resolveSibling("inventory.tmp");
        Files.writeString(temporary, content, StandardCharsets.UTF_8);
        FileSupport.replace(temporary, target);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("draft_path", displayPath(target));
        result.put("sha256", FileSupport.sha256(content));
        result.put("characters", content.length());
        result.put("published", false);
        return result;
    }

    public List<Path> visibleFiles() {
        try (Stream<Path> paths = Files.walk(root)) {
            return paths
                    .filter(Files::isRegularFile)
                    .filter(path -> !Files.isSymbolicLink(path))
                    .filter(path -> !isInternal(path))
                    .sorted()
                    .toList();
        } catch (IOException exception) {
            throw new IllegalStateException("扫描工作目录失败", exception);
        }
    }

    private Path resolve(String relativePath) {
        Path requested = Path.of(relativePath);
        if (requested.isAbsolute()) {
            throw new ToolException("只允许使用工作目录内的相对路径");
        }

        Path current = root;
        for (Path part : requested) {
            current = current.resolve(part);
            if (Files.isSymbolicLink(current)) {
                throw new ToolException("不允许通过符号链接访问文件");
            }
        }

        Path resolved = root.resolve(requested).normalize().toAbsolutePath();
        if (!resolved.startsWith(root)) {
            throw new ToolException("路径越过了工作目录边界");
        }
        return resolved;
    }

    private boolean isInternal(Path path) {
        Path relative = root.relativize(path.toAbsolutePath().normalize());
        return relative.getNameCount() > 0
                && Set.of(".agent", "reports").contains(relative.getName(0).toString());
    }

    private String displayPath(Path path) {
        Path relative = root.relativize(path.toAbsolutePath().normalize());
        return relative.getNameCount() == 0 ? "." : relative.toString().replace('\\', '/');
    }

    private static String suffix(Path path) {
        String name = path.getFileName().toString();
        int index = name.lastIndexOf('.');
        return index < 0 ? "" : name.substring(index).toLowerCase(Locale.ROOT);
    }

    private static String requiredString(Map<String, Object> arguments, String name) {
        Object value = arguments.get(name);
        if (!(value instanceof String text)) {
            throw new ToolException("参数 " + name + " 必须是字符串");
        }
        return text;
    }

    private static void requireOnly(Map<String, Object> arguments, Set<String> expected) {
        if (!arguments.keySet().equals(expected)) {
            throw new ToolException("工具参数字段不匹配，期望：" + expected);
        }
    }

    private static Map<String, Object> searchResult(
            String query,
            List<Map<String, Object>> matches,
            boolean truncated) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("query", query);
        result.put("matches", matches);
        result.put("truncated", truncated);
        return result;
    }

    private static Map<String, Object> error(
            String code,
            String message,
            boolean retryable) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("ok", false);
        result.put("error_code", code);
        result.put("message", message == null ? code : message);
        result.put("retryable", retryable);
        return result;
    }

    private static FunctionTool listFilesSchema() {
        return functionTool(
                "list_files",
                "列出工作目录内的文件、大小和类型。开始盘点时优先调用。不能读取工作目录之外的路径。",
                Map.of(
                        "relative_dir",
                        Map.of("type", "string", "description", "工作目录内的相对目录，例如 . 或 notes")),
                List.of("relative_dir"));
    }

    private static FunctionTool readTextSchema() {
        return functionTool(
                "read_text_file",
                "读取一个已由 list_files 发现的 UTF-8 文本文件。不要猜路径，不支持二进制文件。",
                Map.of(
                        "path",
                        Map.of("type", "string", "description", "工作目录内的相对文件路径")),
                List.of("path"));
    }

    private static FunctionTool searchTextSchema() {
        return functionTool(
                "search_text",
                "在工作目录的文本文件中搜索确定的关键词，返回真实路径、行号和片段。适合查 TODO、FIXME 或用户指定词语。",
                Map.of(
                        "query", Map.of("type", "string", "description", "要搜索的原始关键词"),
                        "relative_dir", Map.of("type", "string", "description", "搜索范围内的相对目录")),
                List.of("query", "relative_dir"));
    }

    private static FunctionTool saveDraftSchema() {
        return functionTool(
                "save_report_draft",
                "把盘点结果保存到受限草稿区，不会覆盖原资料，也不会直接发布。报告必须包含唯一 H1、文件总数：N、## 文件概况、## 需要关注、## 建议下一步，并用反引号标出作为证据的真实相对路径。",
                Map.of(
                        "content",
                        Map.of("type", "string", "description", "完整 Markdown 报告草稿")),
                List.of("content"));
    }

    private static FunctionTool functionTool(
            String name,
            String description,
            Map<String, Object> properties,
            List<String> required) {
        return FunctionTool.builder()
                .name(name)
                .description(description)
                .parameters(FunctionTool.Parameters.builder()
                        .putAdditionalProperty("type", JsonValue.from("object"))
                        .putAdditionalProperty("properties", JsonValue.from(properties))
                        .putAdditionalProperty("required", JsonValue.from(required))
                        .putAdditionalProperty("additionalProperties", JsonValue.from(false))
                        .build())
                .strict(true)
                .build();
    }

    private static final class ToolException extends IllegalArgumentException {
        private ToolException(String message) {
            super(message);
        }
    }
}
