package com.xiaofeng.agent;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ApprovalService {
    private ApprovalService() {}

    public static ApprovalRequest makeRequest(Path draftPath, String token) {
        try {
            String digest = FileSupport.sha256(Files.readAllBytes(draftPath));
            return new ApprovalRequest(token, digest, "APPROVE " + token);
        } catch (IOException exception) {
            throw new IllegalStateException("读取草稿失败", exception);
        }
    }

    public static Path publish(
            Path draftPath,
            Path reportPath,
            ApprovalRequest request,
            String confirmation) {
        if (!confirmation.strip().equals(request.confirmationText())) {
            throw new SecurityException("确认文字不匹配，报告没有发布");
        }

        try {
            byte[] content = Files.readAllBytes(draftPath);
            String currentDigest = FileSupport.sha256(content);
            if (!currentDigest.equals(request.draftSha256())) {
                throw new SecurityException("草稿在确认后发生变化，需要重新检查并确认");
            }

            Files.createDirectories(reportPath.getParent());
            Path temporary = reportPath.resolveSibling("inventory.tmp");
            Files.write(temporary, content);
            FileSupport.replace(temporary, reportPath);
            return reportPath;
        } catch (IOException exception) {
            throw new IllegalStateException("发布报告失败", exception);
        }
    }
}
