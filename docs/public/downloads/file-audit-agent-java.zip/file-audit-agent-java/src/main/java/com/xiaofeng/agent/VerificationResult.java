package com.xiaofeng.agent;

import java.util.List;

public record VerificationResult(
        boolean passed,
        List<String> issues,
        int actualFileCount) {}
