package com.xiaofeng.agent;

import com.openai.client.OpenAIClient;
import com.openai.client.okhttp.OpenAIOkHttpClient;
import com.openai.models.responses.FunctionTool;
import com.openai.models.responses.Response;
import com.openai.models.responses.ResponseCreateParams;
import com.openai.models.responses.ResponseFunctionToolCall;
import com.openai.models.responses.ResponseInputItem;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public final class OpenAIResponsesModel implements AgentModel {
    private final OpenAIClient client;
    private final String model;

    public OpenAIResponsesModel(String model) {
        this(OpenAIOkHttpClient.fromEnv(), model);
    }

    OpenAIResponsesModel(OpenAIClient client, String model) {
        this.client = client;
        this.model = model;
    }

    @Override
    public ModelTurn complete(
            String instructions,
            List<FunctionTool> tools,
            List<ResponseInputItem> inputItems) {
        ResponseCreateParams.Builder builder = ResponseCreateParams.builder()
                .model(model)
                .instructions(instructions)
                .store(false)
                .input(ResponseCreateParams.Input.ofResponse(inputItems));
        tools.forEach(builder::addTool);

        Response response = client.responses().create(builder.build());
        List<ResponseInputItem> items = new ArrayList<>();
        List<ToolCall> calls = new ArrayList<>();

        response.output().forEach(item -> {
            if (item.isFunctionCall()) {
                ResponseFunctionToolCall call = item.asFunctionCall();
                items.add(ResponseInputItem.ofFunctionCall(call));
                calls.add(new ToolCall(call.callId(), call.name(), call.arguments()));
            } else if (item.isReasoning()) {
                items.add(ResponseInputItem.ofReasoning(item.asReasoning()));
            } else if (item.isMessage()) {
                items.add(ResponseInputItem.ofResponseOutputMessage(item.asMessage()));
            }
        });

        String outputText = response.output().stream()
                .flatMap(item -> item.message().stream())
                .flatMap(message -> message.content().stream())
                .flatMap(content -> content.outputText().stream())
                .map(output -> output.text())
                .collect(Collectors.joining("\n"));

        return new ModelTurn(List.copyOf(items), List.copyOf(calls), outputText);
    }
}
