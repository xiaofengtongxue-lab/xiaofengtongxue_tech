package com.xiaofeng.agent;

import java.nio.file.Path;

public record AgentRunResult(
        RunState state,
        Path draftPath,
        VerificationResult verification,
        String finalText) {}
